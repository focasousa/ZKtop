<?php

ob_start();
session_start();

require_once ("config.php");
require_once ("conexao.php");
require_once ("../../string.php");


$dadosWQ = "SELECT* FROM configuracao where id=1";
$conWQ = $mysqli -> query($dadosWQ) or die ($mysqli -> error);


while ($consultaWQ= $conWQ -> fetch_array()){
	
	$ip_ex = $consultaWQ ["ip_ex"];
	
	$msg_final = $consultaWQ ["msg_final"];

	
	
}

$ID_SKU = $_SESSION ['sku_id'];




$redirect = '../../'.$base.'/?sku='.$_SESSION ['sku_id'].'';

$ip_ban = $_SERVER["REMOTE_ADDR"];


$sql1="SELECT count(id) AS  total FROM blacklist where ip='$ip_ban'";

$result=mysqli_query($mysqli,$sql1);
$values=mysqli_fetch_assoc($result);
$ban_list=$values['total'];

if ($ban_list > 0) {
	
	
	header("Location: $redirect");

	
} else {





$ip = $_SERVER['REMOTE_ADDR'];
//$ip = '200.142.120.90';
//$ip = '2a03:2880:20ff:6::face:b00c';
$termo = 'face';

$pattern = '/' . $termo . '/';
if (preg_match($pattern, $ip)) {
	
  
  	$dadosVX7 = "SELECT* FROM contador_2 ";
	$conVX7 = $mysqli -> query($dadosVX7) or die ($mysqli -> error);
	
	while ($consultaVX7= $conVX7 -> fetch_array()){
	
	 $x9_num_a = $consultaVX7["x9"];
	
	}	
	$x9_num = $x9_num_a+1;
	
$sql = "Update contador_2 SET x9 ='$x9_num' where id='1' " ;
$query = $mysqli->query($sql);
  

	 header("Location: $redirect");





} else {
	
	
	  $url = "https://whatismyipaddress.com/ip/".$ip."";

$options = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Accept-language: pt\r\n" .
              "Cookie: foo=bar\r\n" .  
              "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36" 
  )
);

$context = stream_context_create($options);
	
$file = file_get_contents($url, false, $context);




$explode_1 = explode('<tr><th>ISP:</th><td>',$file);
$explode_2 = explode("</td>",$explode_1[1]);

$explode_3 = explode('<tr><th>Organization:</th><td>',$file);
$explode_4 = explode("</td>",$explode_3[1]);







if ($explode_2 [0] == "Facebook" or $explode_4 [0] == "Facebook" ) {
	
	
	$dadosVX7 = "SELECT* FROM contador_2 ";
	$conVX7 = $mysqli -> query($dadosVX7) or die ($mysqli -> error);
	
	while ($consultaVX7= $conVX7 -> fetch_array()){
	
	 $x9_num_a = $consultaVX7["x9"];
	
	}	
	$x9_num = $x9_num_a+1;
	
$sql = "Update contador_2 SET x9 ='$x9_num' where id='1' " ;
$query = $mysqli->query($sql);



	
	header("Location: $redirect");
	
	
	
} 



$palavras = array(
   'facebookexternalhit',
   'facebook',
   'external',
   'face',
   'hit',
   'Googlebot',
   'Facebot',
   'Nexus 6P',
   'Nexus 5X'
  



);


$useragent=$_SERVER['HTTP_USER_AGENT'];


if( preg_match( sprintf( '/%s/i', implode( '|', $palavras ) ), $useragent ) )
{


	$dadosVX7 = "SELECT* FROM contador_2 ";
	$conVX7 = $mysqli -> query($dadosVX7) or die ($mysqli -> error);
	
	while ($consultaVX7= $conVX7 -> fetch_array()){
	
	 $x9_num_a = $consultaVX7["x9"];
	
	}	
	$x9_num = $x9_num_a+1;
	
$sql = "Update contador_2 SET x9 ='$x9_num' where id='1' " ;
$query = $mysqli->query($sql);

	 header("Location: $redirect");
	 


} 

	
  
  
}












function filtro_system($sql)
{
	
	$palavras_cad = array(
   'from ',
   'alter table',
   'select ',
   'insert ',
   'delete ',
   'update ',
   'where ',
   'drop table',
   'show tables',
   'order ',
   'order by',
   'or 1=1',
   '<input',
   '<script>',
   ' or ',
   'declare ',
   'exec ',
   'set ',
   'eval ',
   '<form'
   
);

	$replace = array(
   '<font color="red">from</font>',
   '<font color="red">alter table</font>',
   '<font color="red">select</font>',
   '<font color="red">insert</font>',
   '<font color="red">delete</font>',
   '<font color="red">update</font>',
   '<font color="red">where</font>',
   '<font color="red">drop table</font>',
   '<font color="red">show tables</font>',
   '<font color="red">order</font>',
   '<font color="red">order by</font>',
   '<font color="red">or 1=1</font>',
   '<font color="red"><input</font>',
   '<font color="red"><cript></font>',
   '<font color="red"> or </font>',
   '<font color="red">declare</font>',
   '<font color="red">exec</font>',
   '<font color="red">set</font>',
   '<font color="red">eval</font>',
   '<font color="red"><form</font>'
   
);



$formata = strtolower($sql);




	
	
	
	

if( preg_match( sprintf( '/%s/i', implode( '|', $palavras_cad ) ), $sql ) )
{
	

	
	
$nova_string = str_replace($palavras_cad, $replace, $formata);


$dia=date("d/m/Y");

$ipz = $_SERVER["REMOTE_ADDR"];


	
	
	
	$tudo = '
	           <tr >
          
                  <td><small>'.$ipz.'</small></td>
				  <td><small>'.$nova_string.'</small></td>
				  <td><small>'.$dia.'</small></td>
				
                </tr>
';

$fopen = fopen("logs_atack.txt", "a");
fwrite($fopen, $tudo);
fclose($fopen);



  $sqla = "Vazio";
  return $sqla;



} else {
	
$sqla = addslashes($sql);

return $sqla;

}
}






}
?>