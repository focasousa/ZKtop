<?php 
ob_start();
session_start();


if(isset($_SESSION['login_user']))
	{




require_once ("config.php");
require_once ("conexao.php");


$LINK_A = $_POST["link"];
$EMAIL_A = $_POST["email"];
$ANTI_A = $_POST["anti"];
$DESCONTO_A = $_POST["desconto"];
$VENCIMENTO_A = $_POST["vencimento"];
$MSG_FINAL_A = $_POST["msg_final"];
$MSG_ERRO_A = $_POST["msg_erro"];
$MSG_SUCESSO_A = $_POST["msg_sucesso"];
$NOME_LETO_A = $_POST["nome_leto"];
$IP_EX_A = $_POST["ip_ex"];
$REDIRECT_A = $_POST["redirect"];
$FACE_A = $_POST["face"];


$LINK =  addslashes($LINK_A);
$EMAIL =  addslashes($EMAIL_A);
$ANTI_1 =  addslashes($ANTI_A);
$DESCONTO =  addslashes($DESCONTO_A);
$VENCIMENTO =  addslashes($VENCIMENTO_A);
$MSG_FINAL =  addslashes($MSG_FINAL_A);
$MSG_ERRO=  addslashes($MSG_ERRO_A);
$MSG_SUCESSO =  addslashes($MSG_SUCESSO_A);
$NOME_LETO =  addslashes($NOME_LETO_A);
$REDIRECT =  addslashes($REDIRECT_A);
	
	
	
	if (empty($IP_EX_A)) {
	
	
	$IP_EX = "2" ;
	
} else {
	
	
	$IP_EX =  addslashes($IP_EX_A);



}

	if (empty($FACE_A)) {
	
	
	$FACE = "0" ;
	
} else {
	
	
$FACE =  addslashes($FACE_A);



}

	
	
	if (empty($ANTI_1)) {
	
	
	$ANTI = "2" ;
	
} else {
	
	
	$ANTI =  addslashes($_POST ['anti']);


}


$dadosB = "SELECT* FROM configuracao where id=1";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$img_leto = $consultaB ["img_leto"];

	
	
}


$pega1 =  $_FILES['img1']['name'] ; 
$palavras = array(
   '.exe',
   '.php',
   'php',
   '.html',
   '.bat',
   '.json',
   '.html',
   '.js',
   '.css',
   '.xtml'
);



if( preg_match( sprintf( '/%s/i', implode( '|', $palavras ) ), $pega1 ) )
{
	
header("Location: ../add_mods.php?atak=ok");


} else {



if (isset($_FILES ['img1'])){
	
	$ip = $_SERVER['REMOTE_ADDR'];
	$extensao1 = strtolower (substr($_FILES ['img1']['name'], -4 ));
	$novo_nome1 = md5 (time()). $extensao1;
	$diretorio = "../assets/img/";
	move_uploaded_file ($_FILES ['img1']['tmp_name'], $diretorio.$novo_nome1);
}  

}


$pega2 =  $novo_nome1 ; 
$palavras2 = array(
   '.jpg',
   '.png'
);


if( preg_match( sprintf( '/%s/i', implode( '|', $palavras2 ) ), $pega2 ) )
{
	
$novo_nomeX = $novo_nome1;

} else {



$novo_nomeX = $img_leto ;


}


	
	
	
	
if (isset($_POST ['config1'] )) {
	
	

$sql = "Update configuracao SET nome_leto ='$NOME_LETO', img_leto ='$novo_nomeX', link_site='$LINK', email='$EMAIL', anti_phising='$ANTI' , vencimento='$VENCIMENTO', desconto='$DESCONTO', ip_ex='$IP_EX', redirect='$REDIRECT', face='$FACE' where id=1 " ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../configuracao.php?acao=1&config=2"));
  else
    echo (header("Location: ../configuracao.php?acao=1&config=1"));


	
	
	
}






if (isset($_POST ['config2'] )) {
	
	

$sql = "Update configuracao SET msg_erro='$MSG_ERRO', msg_sucesso='$MSG_SUCESSO', msg_final='$MSG_FINAL' where id=1 " ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../configuracao.php?acao=2&config=2"));
  else
    echo (header("Location: ../configuracao.php?acao=2&config=1"));


	
	
	
}






	}	
	


?>    


