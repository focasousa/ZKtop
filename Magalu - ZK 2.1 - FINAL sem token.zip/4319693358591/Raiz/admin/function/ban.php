<?php





ob_start();
session_start();

if(isset($_SESSION['login_user']))
	{


error_reporting(0);
ini_set(“display_errors”, 0 );

require_once ("config.php");
require_once ("conexao.php");





$data=date("d/m/Y");
$IP =  addslashes($_GET ['ip']);









$sql = "INSERT INTO blacklist (ip, dia) VALUES ('$IP', '$data' )";
   $query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../analise.php?add=2"));
  else
    echo (header("Location: ../analise.php?add=1"));


	}
?>

