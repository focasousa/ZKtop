<?php
require_once ("config.php");


	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
?>