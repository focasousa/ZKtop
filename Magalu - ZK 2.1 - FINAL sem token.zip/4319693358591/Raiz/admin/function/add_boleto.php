<?php

ob_start();
session_start();

if(isset($_SESSION['login_user']))
	{


$teste = $_POST ['boletos'] ;
$ID = $_POST ['id'] ;

$teste_1 =  nl2br($teste);


if (isset($_POST ['boletos']) and ($_SESSION['login_user'])) {
   
require_once ("config.php");
require_once ("conexao.php");
   

$string1 = "".$teste_1."";
$stringCorrigida1 = str_replace("<br />","','$ID'),('",  $string1);

$string2 = "".$stringCorrigida1."";
$stringCorrigida2 = str_replace(" ","",  $string2);




$imprimir =  "('".$stringCorrigida2."','$ID')";

$sql1 = "INSERT INTO boletos (numero, id_produto) VALUES 

$imprimir

" ;
$query = $mysqli->query($sql1);

  if(!$query)
    die (header("Location: ../boletos.php?id=$ID&leto=2"));
  else
    echo (header("Location:../boletos.php?id=$ID&leto=1"));

mysqli_close($mysqli);

}

	}

?>