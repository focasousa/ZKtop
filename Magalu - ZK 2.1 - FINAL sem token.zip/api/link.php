<?php 
// SERVE PARA SALVAR OS LINKS NOS SLOTS DA LICENÇA //

//     [tk] => 33
//     [slot] => 1
//     [host] => localhost