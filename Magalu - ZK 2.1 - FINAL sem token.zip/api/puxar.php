<?php
require_once("../string.php");
?>
 'a' =>1<br>
 'b' =>Dev<br>
 'c' =>2035-12-15<br>
 '1' =><?php echo $site_urlvl; ?><br>
 '2' =><?php echo $site_urlvl; ?><br>
 '3' =><?php echo $site_urlvl; ?><br>

 

