<?php
 require_once ('../../string.php');

?>

<head>
<meta http-equiv="refresh" content="0;url=../../<?php echo $null2?>/Raiz/admin/">
</head>

<body>
<center>
<img src="../../default.jpg">
</body>